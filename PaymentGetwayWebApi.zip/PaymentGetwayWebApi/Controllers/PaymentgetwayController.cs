﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using PaymentGetwayWebApi.Models;

namespace PaymentGetwayWebApi.Controllers
{
    public class PaymentgetwayController : ApiController
    {
              
        public string Get()
        {
           
            //string param = "account_token=1415E38BCE6D540E358EEEF98254A967CECA2C9546B7C4FCEFA54822 83DA5FEA9C50BC5DDDE6E51B73&full_detail_flag=true&transaction_type=CREDIT_CARD&charge_type=QUERY_PAYMENT&order_id=1223";
            //string accountToken = "3B4B9533CE6C5908398CEDF98152AA67C3CA259647B8C2F9EEA84C2580DE5AE89954BC556DA04F1F";
            try
            {
                int TransactionID = Convert.ToInt32( DateTime.UtcNow.Ticks/10000000000);
                int Amount = 500;
                Paymentmodel pm = new Paymentmodel();
                string paypageUrl = pm.GetPaybyCredit(TransactionID, Amount);
                return paypageUrl;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
    }

}
 