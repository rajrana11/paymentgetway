﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Configuration;
namespace PaymentGetwayWebApi.Models
{
    public class Paymentmodel

    {
        public string xweb_id { get; set; }
        public string terminal_id { get; set; }
        public string auth_key { get; set; }
        public string transaction_typeCredit { get; set; }
        public string OpenEdgeUrl { get; set; }
        public string transaction_typeACH { get; set; }
        public string charge_type { get; set; }
        public string entry_method { get; set; }

        public Paymentmodel()
        {
            xweb_id = ConfigurationManager.AppSettings["xweb_id"].ToString();
            terminal_id = ConfigurationManager.AppSettings["terminal_id"].ToString();
            transaction_typeCredit = ConfigurationManager.AppSettings["transaction_type_Credit"].ToString();
            transaction_typeACH = ConfigurationManager.AppSettings["transaction_typeACH"].ToString();
            auth_key = ConfigurationManager.AppSettings["auth_key"].ToString();
            OpenEdgeUrl = ConfigurationManager.AppSettings["OpenEdgeUrl"].ToString();
            charge_type = ConfigurationManager.AppSettings["charge_type"].ToString();
            entry_method = ConfigurationManager.AppSettings["entry_method"].ToString();
            

        }
        public static String GetPayPageUrl(String accountToken, String url, String parameters)
        {
            String postData = "account_token=" + accountToken + "&" + parameters;
            HttpWebRequest request = BuildWebRequest(postData, url);
            return ParseResponse(request.GetResponse() as HttpWebResponse);
        }
        public static String GetPayPageUrl(String url, String parameters)
        {
            String postData = parameters;
            HttpWebRequest request = BuildWebRequest(postData, url);
            return ParseResponse(request.GetResponse() as HttpWebResponse);
        }
        public string GetPaybyCredit(int orderno, int charge_total)
        {
            string postData = "xweb_id=" + xweb_id + "&" + "terminal_id=" + terminal_id + "&" + "charge_type=" + charge_type + "&" + "order_id=" + orderno + "&" + "transaction_type=" + transaction_typeCredit + "&" + "auth_key =" + auth_key + "&" + "charge_total =" + charge_total + "&" + "entry_method =" + entry_method;//  entry_method + "&" + orderno;
            HttpWebRequest request = BuildWebRequest(postData, OpenEdgeUrl);
            return ParseResponse(request.GetResponse() as HttpWebResponse);
        }
        public static String GetPayPageUrl(String xweb_id, String terminal_id, String auth_key, String url, string transaction_type, string chage_type, String parameters)
        {
            String postData = "xweb_id=" + xweb_id + "&" + "terminal_id=" + terminal_id + "&" + "charge_type=" + chage_type + "&" + "transaction_type=" + transaction_type + "&" + "auth_key =" + auth_key + "&" + parameters;
            HttpWebRequest request = BuildWebRequest(postData, url);
            return ParseResponse(request.GetResponse() as HttpWebResponse);
        }
        public static String GetPayPageUrl(String xweb_id, String terminal_id, string auth_key, string url, string transaction_type, string parameters)
        {

            String postData = "xweb_id=" + xweb_id + "&" + "terminal_id=" + terminal_id + "&" + "transaction_type=" + transaction_type + "&" + "auth_key =" + auth_key + "&" + parameters;
            HttpWebRequest request = BuildWebRequest(postData, url);
            return ParseResponse(request.GetResponse() as HttpWebResponse);
        }

        private static String ParseResponse(HttpWebResponse response)
        {
            Stream stream = response.GetResponseStream();
            StreamReader reader = new StreamReader(stream);           
           
            string result= reader.ReadToEnd();
            stream.Dispose();
            reader.Dispose();
            return result;
            //var jsonSerializer = new DataContractJsonSerializer(typeof(Response));
            //object objResponse = jsonSerializer.ReadObject(stream);
            //var jsonResponse = objResponse as Response;
            //if (jsonResponse.ErrorMessage != null)
            //{
            //    throw new Exception(jsonResponse.ErrorMessage);
            //}
            //return jsonResponse.ActionUrl + jsonResponse.SealedSetupParameters;
        }

        private static HttpWebRequest BuildWebRequest(String postData, String url)
        {
            HttpWebRequest request = WebRequest.Create(url) as HttpWebRequest;
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            byte[] byteArray = Encoding.UTF8.GetBytes(postData);
            request.ContentLength = byteArray.Length;
            Stream dataStream = request.GetRequestStream();   // Get the request stream.                            
            dataStream.Write(byteArray, 0, byteArray.Length);   // Write the data to the request stream.         
            dataStream.Close();  // Close the Stream object.             
            return request;
        }

    }
    
    [DataContract]
    public class Response
    {
        [DataMember(Name = "sealedSetupParameters")]
        public string SealedSetupParameters { get; set; }
        [DataMember(Name = "actionUrl")]
        public string ActionUrl { get; set; }
        [DataMember(Name = "errorMessage")]
        public string ErrorMessage { get; set; }
    }
}